# Model Evaluation Script

from sklearn.metrics import accuracy_score
...