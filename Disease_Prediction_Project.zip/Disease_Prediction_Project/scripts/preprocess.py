# Data Preprocessing Script

import pandas as pd
...