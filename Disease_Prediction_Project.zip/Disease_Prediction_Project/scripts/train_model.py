# Model Training Script

from sklearn.model_selection import train_test_split
...